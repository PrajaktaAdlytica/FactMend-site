# Factmend motion implementation

Motion explains the product story and preserves reading order.

| Scene | Behavior | Meaning |
| --- | --- | --- |
| Homepage hero | Perspective and shallow background scrub | Source, governed record, and destinations form one system |
| Lifecycle | Sticky visual beside five scroll chapters; stage changes forward and backward | Learn → scope → correct → erase → check |
| Product stories | Three scroll chapters with changing product state | Show input, operation, and resulting evidence |
| Platform map | Staggered source/core/destination reveal | Explain the relationships between modules |
| Diagram paths | Scroll-scrubbed SVG strokes | Show flow direction and sequence |
| Page sections | Small vertical reveal | Introduce the next reading group without disrupting layout |
| Evidence card | Explicit, reversible flip interaction | Reveal the checked and unresolved boundaries |
| Cards and controls | Border trace, slight lift, directional arrows, clear focus | Indicate interaction and current state |

Lenis sends scroll updates to ScrollTrigger and is advanced by the GSAP ticker; there is no second RAF loop. GSAP contexts revert on route changes, ticker callbacks are removed, Lenis is destroyed, and triggers refresh after fonts load. Native touch scrolling remains enabled.

Desktop story scenes use CSS sticky positioning with ScrollTrigger stage selection at 1000px+ viewport width and 700px+ height. Narrow or short viewports show all chapters and widgets in normal reading flow. Wide diagrams and tables scroll within their own region instead of forcing the whole page wider.

Reduced motion follows the operating-system setting or the explicit footer control. It disables transforms and smooth scrolling and exposes every narrative step. Product information never depends solely on animation or hover. Interactive controls retain visible focus, state text, and accessible labels.

Assessment and workspace behavior use real local state. Simulated checks explicitly preserve the unverified backup boundary; their loading/failure/retry states do not imply a connected service.
